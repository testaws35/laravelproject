@extends('layouts.app1')
@section('content')

<!-- {{-- /**
// classname - Announcements/Show.blade.php
// author - Raveendra 
// release version - 1.0
// Description-  This view Ui is used showing a specific Announcement
// created date - Nov 2019
**/ --}} -->




 <div class="container">
           <div class="row">
               
        <?php if (  isset($announcement)    ) { ?>
                <div class="col-lg-9 col-9">
                       
                        <div class="post_wrapper">
                             <div class="post_header">
                                    <h2 style="font-family: 'Sen', sans-serif;" class="text-center">{{ $announcement->Title }}    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                      <!--   {{--Aruna added Edit button will be shown if User is Admin 
                                             or if the user is the author of the post and he can edit within 30 days 
                                             ( ($announcement->CreatedOn  > date('Y-m-d', strtotime(' - 30 days'))  ) && ($announcement->CreatedOn <= date('Y-m-d'))  ) ) 
                                              ---}} -->

                                             <?php if( (Auth::user()->userroleID==2) ||   (  ( $announcement->Createdby == Auth::user()->id)  )  )  {  ?>
                                                        <a href="{{ route('announcements.edit',$announcement->AnnouncementsID) }}" class="pull-center"><b style="font-size:10px;"><i class="fas fa-user-edit fa-3x" title="Edit Announcement"></i> </b></a> 
                                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                             <?php }?>   
                                         <a href="{{ route('announcements.index') }}" class="pull-left"><b style="font-size:10px;"><i class="fa fa-arrow-left fa-3x" title="Back to Announcements"></i></b></a></h2>
                                    <div class="blog-date-categori">
                                        <ul>
                                             </li>
                                       
                                        </ul>
                                    </div>
                                </div>

                                <div class="card card-profile">
                                    <div class="card-header card-header-image" style="height:100 ; width:80%; margin-top:50px;">
                                            <a href="#">
                                                <img class="img-thumbnail" src="{{$announcement->Photo}}" >  
                                            </a>

                                            <!--<div class="colored-shadow" style="background-image: url('{{ $announcement->Photo}}');opacity: 1;">
                                            </div>   -->
                                    </div>
                        </div>
                        <div class="blog-date-categori" style="margin-top:30px;">
                                        
                                        <ul>
                                            <li>Posted By : {{ $announcement->name }}
                                            </li>
                                        </ul>

                                    </div>


                                <hr/>
                                <div class="post_content">
                                    <p><b class="text-uppercase">Description:</b> <br/> {{ $announcement->Function_Content }}</p>
                               </div>
                               <hr/>
                         </div>

                </div>
                <?php } else {   ?>

                    <p> <h4 class="alert alert-info"> Sorry... This announcement is not found</h4> </p>
                <?php } ?>
                <!-- This is the recent announcement panel in RHS --->
                <div class="col-lg-3 col-12 md-mt-40 sm-mt-40">
                    <div class="wn__sidebar">
                       <!-- Start Single Widget -->
                        <aside class="widget recent_widget">
                            <h3 class="widget-title">Recent Announcements</h3>
                            <div class="recent-posts">
                                <ul>
                                    <li>
                                                @foreach ($announcements->take(5) as $anment)
                                                    <div class="thumb" style="max-width:900px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"> 
                                               
                                                    @if($anment->Photo )
                                                    <a href="{{ route('announcements.show',$anment->AnnouncementsID) }}" style="text-decoration:none; "><img src="{{ $anment->Photo }}" alt="/images/announcements/Announcement_default.png" class="rounded-circle"  width="50" height="50">&nbsp;{{ $anment->Title }}  </a>
                                                    @else 
                                                    <img class="img-thumbnail" src="/images/announcements/Announcement_default.png" alt="announcements" class="rounded-circle"  width="50" height="50">
                                                   @endif
                                                    <hr>
                                                @endforeach
                                    </li>
                                 </ul>
                            </div>
                        </aside>
                        <!-- End Single Widget -->

                          <!-- Start Single Widget -->
      <aside class="wedget__categories poroduct--cat">
            <h3 class="wedget__title"><b>Archives </b></h3>
            <ul>
                
                <li><a href="{{ url('/announcements/?mon=1') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 1 months')  ) ); ?></a></li>
                <li><a href="{{ url('/announcements/?mon=2') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 2 months')  ) ); ?></a></li>
                <li><a href="{{ url('/announcements/?mon=3') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 3 months')  ) ); ?></a></li>
                <li><a href="{{ url('/announcements/?mon=4') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 4 months')  ) ); ?></a></li>
                <li><a href="{{ url('/announcements/?mon=5') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 5 months')  ) ); ?></a></li>
                <li><a href="{{ url('/announcements/?mon=6') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 6 months')  ) ); ?></a></li>
              
            </ul>
        </aside>
        <!-- End Single Widget -->
                      </div>
                </div>
                
            </div><!-- END ROW-->


        {{-- </div> --}}
    </div>
    @include('sweetalert::alert')




@endsection
