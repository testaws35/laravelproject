@extends('layouts.app1')
@section('content')

<!-- {{-- /**
// classname - Helpposts/Edit.blade.php
// author - Raveendra 
// release version - 1.0
// Description-  This view Ui is used for editing FAQ
// created date - Nov 2019
**/ --}} -->


            <div class="row">

                <div class="col-lg-12 margin-tb">

                    <div class="pull-left">

                        <h2>Edit Help Post</h2>

                    </div>

                    <div class="pull-right">

                        <a class="btn btn-primary" href="{{ route('helpposts.index') }}"> Back</a>

                    </div>

                </div>

            </div>


            @if (count($errors) > 0)
            <div>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif

<?php if(isset($helppost)) {?>

<form action="{{ route('helpposts.update', $helppost->HelpID) }}" method="POST">


    <input type="hidden" name="_method" value="PUT">

    @csrf

     <div class="row">

        <div class="col-md-12">
            
            <strong>Title:</strong>

             <input type="text" name="Type" value="{{ $helppost->Type }}"  class="form-control" placeholder="Type" disabled><br/><br/>


        </div>
        
     <div class="col-md-12">

    <strong>Description:</strong>
   
    <textarea type="text" name="Description" class="form-control"  rows="15" placeholder="Description">{{ $helppost->Description }}</textarea>
    <br/><br/>
    </div>

 




        <div class="col-xs-12 col-sm-12 col-md-12 text-center">

          <button type="submit" class="btn btn-info">Update</button>

        </div>

    </div>



</form>

<?php } else {?>
    <p> <h2> Sorry unable to get details of the Help Post. Try again ! </h2> <p>
<?php } ?>

@endsection
