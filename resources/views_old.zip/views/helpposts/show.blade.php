@extends('layouts.app1')
@section('content')

<!-- {{-- /**
// classname - Helpposts/show.blade.php
// author - Raveendra 
// release version - 1.0
// Description-  This view Ui is used for diplaying specific FAQ post
// created date - Nov 2019
**/ --}} -->


<!-- End Bradcaump area -->
<?php if(isset($helppost ) )   {?>
<div class="page-blog-details section-padding--lg bg--white">
   <div class="container">
       <div class="row" >  <!-- outer row -->
             <div class="col-lg-9 col-12">  <!-- 1st column -->
                    <div class="blog-details content">
                        <article class="blog-post-details">

                            <h2 class="text-center">{{ $helppost->Type }}    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;     <a href="{{ route('helpposts.index') }}" class=" pull-left" title="Back to helpposts"><b style="font-size:10px;"><i class="fa fa-arrow-left fa-3x"></i></b></a></h2>
                            
                            <div class="post-thumbnail"><!-- images\frontend_images\blog\big-img\1.jpg -->
                                <div class="card-header card-header-image">
                                        <a href="#pablo">
                                        <img class="img-thumbnail" src="{{ $helppost->Photo }}" style="max-height: 400px;width:90%; margin-top:30px;">
                                        </a>
                                        <div class="colored-shadow" style="background-image: url('{{ $helppost->Photo }}');opacity: 1;">
                                        </div>
                                </div>
                            </div>
                            <div class="post_wrapper">
                                    <div class="post_header">
                                        
                                        <div class="blog-date-categori">
                                            <ul>
                                                <li>Posted On : {{ date('d-M-Y', strtotime($helppost->created_at)) }}
                                                </li>
                                            </ul>
                                            <ul>
                                                <li>Posted By : {{ $helppost->name }}
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="post_content">
                                        <p>{{ $helppost->Description }}</p>
                                    </div>
                             </div>
                             <hr/>
                        </article>
                     
                        <?php if(( isset($comments)) && (count($comments) >0) )  { ?>
                            <div class="comment_respond">
                                {{--   <h3 class="reply_title"><b>Comments</b></h3> --}}
                                  <h3 class="reply_title">Comments</h3>
                                  <hr />
                            {{--   @include('partials._helpcomment_replies', ['comments' => $comments]) --}}
                            </div>   
                                  
                        <?php } ?> <!-- inner if-->



                        
                        <br/> <br/>
                        <form class="comment__form1" method="post" action="{{route('comment.add')}}">
                                {!! csrf_field() !!}
                                <h3 class="reply_title" style="font-family: 'Sen', sans-serif;">Leave a Reply {{-- <small><a href="#">Cancel reply</a></small> --}}</h3>
                                <hr />
                                <div class="input__box" style="font-family: 'Sen', sans-serif;">
                                <p class="lead emoji-picker-container">
                                        <textarea name="comment_body" class="form-control" rows="10" placeholder="Your comment here" data-emojiable="true"></textarea>
                                         <input type="hidden" name="post_id" value="{{ $helppost->HelpID }}" />
                                </div>
                             
                                <div class="submite__btn">
                                        <input type="submit" class="btn" style="font-family: 'Sen', sans-serif;font-size:16px;border-bottom-right-radius:25px;border-top-left-radius:25px;background: #f82249;color:#fff;" value="Add Comment" />
                                </div>
                        </form> 

                      
                    </div> <!-- blog details content-->
             </div>  <!-- end 1st col-->
        
             <div class="col-lg-3 col-12 md-mt-40 sm-mt-40">
                    <div class="wn__sidebar">
                      <!-- Start Single Widget -->
                        <aside class="widget recent_widget">
                                    <h3 class="widget-title">Recent Posts</h3>
                                    <div class="recent-posts">
                                        <ul>
                                            <li>
                                            @foreach ($helpposts->take(5) as $helppost)
                                                <div class="thumb" style="max-width:900px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"> 
                                                        <a href="{{ route('helpposts.show',$helppost->HelpID) }}" style="text-decoration:none; "><img src="/images/helppost/{{ $helppost->Photo }}" alt="Help Posts" class=" rounded-circle" width="50" height="50">&nbsp;
                                                        {{ Illuminate\Support\Str::limit(ucwords($helppost->Description), 80, $end='...') }}</a>
                                                </div>
                                            @endforeach
                                            </li>
                                        </ul>
                                    </div>
                        </aside>
                        <!-- End Single Widget -->
                     </div> <!-- end side bar-->
                </div>

                
            </div>  <!--end col2 -->
                
         </div><!-- END outer  ROW-->
         
     </div> <!-- container-->
 <!--</div>  remove div on 19-1-2020 page blog-->
<?php } else { ?>


    <div class="page-blog-details section-padding--lg bg--white">
            <div class="container">
                <div class="row" >  <!-- outer row -->
                      <div class="col-lg-9 col-9">  <!-- 1st column -->
                         <div class="row">
                         </div> <!-- end row -->
                          <p style="font-family: 'Sen', sans-serif;"> <br>  <br> <br><br>  <br> <br> <b> {{$Failed}}  </b></p>
                         </div> <!-- end row -->
                      </div>  <!-- end 1st col-->
                 
                      <div class="col-lg-3 col-3 md-mt-40 sm-mt-40">
                             <div class="wn__sidebar">
                               <!-- Start Single Widget -->
                                 <aside class="widget recent_widget">
                                     <h3 class="widget-title" style="font-family: 'Sen', sans-serif;">Recent Posts</h3>
                                     <div class="recent-posts">
                                         <ul>
                                             <li>
                                               @foreach ($helpposts->take(5) as $helppost)
                                                  <div class="thumb" style="max-width:900px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"> 
                                                            <a href="#"><img src="/images/helppost/{{ $helppost->Photo }}" alt="Help Posts" class="rounded-circle" width="50" height="50"></a>
                                                   </div><br/>
                                                  <div class="content" style="font-family: 'Sen', sans-serif;">
                                                               <h4>    {{ $helppost->Type }}</h4>
                                                                {{ $helppost->Description }}
                                                 
                                                  </div><br/>
                                               @endforeach
                                             </li>
                                         </ul>
                                     </div>
                                 </aside>
                                 <!-- End Single Widget -->
                              </div> <!-- end side bar-->
                         </div>
                     </div>  <!--end col2 -->
                         
                  </div><!-- END outer  ROW-->
              </div> <!-- container-->
          </div> <!-- page blog-->


<?php } ?>


<script id="dsq-count-scr" src="//www-tecpleglobal-com.disqus.com/count.js" async></script>


@endsection
