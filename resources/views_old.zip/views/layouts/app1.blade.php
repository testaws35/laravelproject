<!DOCTYPE html>
<!-- <html lang="{{ str_replace('_', '-', app()->getLocale()) }}">  -->
    <html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Welcome to Telungu  Viswakarma TN </title>

    <!-- Scripts --
    <script src="{{ asset('js/app.js') }}" defer></script>
    -->
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Sen&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <!-- Favicons -->


  <link rel="stylesheet" href="{{ asset('css/frontend_css/bootstrap.min.css') }}" />
<link rel="stylesheet" href="{{ asset('css/frontend_css/custom.css') }}" />
<link rel="stylesheet" href="{{ asset('css/frontend_css/plugins.css') }}" />
<link rel="stylesheet" href="{{ asset('css/style.css') }}" />
<link rel="stylesheet" href="{{ asset('images/frontend_images/icons') }}" /> 
 <link href="{{ asset('lib/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" /> 
    <link rel="stylesheet" href="{{ asset('css/jquery.toast.css') }} ">

	<!-- Modernizer js -->
<script src="{{ asset('js/frontend_js/vendor/modernizr-3.5.0.min.js') }}"></script>
       <script src="{{ asset('js/jquery-3.3.1.min.js') }}"></script>
         <!--  emoji -->
 <link rel="stylesheet" href="{{ asset('css/frontend_css/emoji.css')}}" />
        <!-- end emoji   -->
<script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
<style>

/* Limiting column data */
.mytable p{
  max-width:900px; /* Customise it accordingly */
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.mytable h4{
  max-width:500px; /* Customise it accordingly */
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
/* END Limiting column data */

p {
    font-size: 14px;
    margin: 0 0 10px;
    font-weight: 300;
    
}

.text-gray {
    color: #999!important;
}

.card-title{
    font-weight: 700 !important;
    margin-top: 10px;
    color: #3c4858;
    font-family: 'Sen', sans-serif;
}
.card {
    border: 0;
    margin-bottom: 30px;
    margin-top: 100px;
    border-radius: 6px !important;
    color: rgba(0,0,0,.87);
    background: #fff;
    width: 100%;
    box-shadow: 0 2px 2px 0 rgba(0,0,0,.14), 0 3px 1px -2px rgba(0,0,0,.2), 0 1px 5px 0 rgba(0,0,0,.12);
}

.card .card-body{
    padding: .9375rem 1.875rem;
}

.card-description{
    color: #999;
}

.card.card-profile{
    text-align: center;
}
.card .card-header.card-header-image {
    position: relative;
    padding: 0;
    z-index: 1;
    margin-left: 15px;
    margin-right: 15px;
    margin-top: -81px;  /* -30px to 81px dec 15 2020*/
    border-radius: 6px;
    max-height: 215px;
}

.card .card-header.card-header-image a {
    display: block;
}

.card .card-header.card-header-image img {
    width: 100%;
    height: 215px;
    border-radius: 6px;
    pointer-events: none;
    box-shadow: 0 5px 15px -8px rgba(0,0,0,.24), 0 8px 10px -5px rgba(0,0,0,.2);
}

.card-home-header-image img {
    width: 100%;
    height: 215px;
    border-radius: 6px;
    pointer-events: none;
    box-shadow: 0 5px 15px -8px rgba(0,0,0,.24), 0 8px 10px -5px rgba(0,0,0,.2);
}




.card .card-header.card-header-image .colored-shadow {
    transform: scale(.94);
    top: 12px;
    filter: blur(12px);
    position: absolute;
    width: 100%;
    height: 100%;
    background-size: cover;
    z-index: -1;
    transition: opacity .45s;
    opacity: 1;
}

.card .card-header.card-header-image .card-title {
    position: absolute;
    bottom: 5px;
    left: 15px;
    color: #fff;
    font-size: 1.125rem;
    text-shadow: 0 2px 5px rgba(33,33,33,.5);
    font-weight: 700;
    font-family: 'Sen', sans-serif;
}

.card .card-category {
    margin-top: 15px;
    margin-bottom: 10px;
}

.card .card-body+.card-footer {
    padding-top: 0;
    border: 0;
    border-radius: 6px;
}

.card .card-footer {
    display: flex;
    align-items: center;
    background-color: transparent;
    border: 0;
}

.card-profile .card-footer .btn.btn-just-icon{
    font-size: 20px;
    padding: 12px 13px;
    line-height: 1em;
}

.card .card-footer {
    padding: .9375rem 1.875rem;
}


.card-profile .card-body+.card-footer{
    margin-top: -15px;
}
.card .text-info {
    color: #00bcd4!important;
}

.card-profile .card-avatar {
    width: 130px;
    max-width: 130px;
    max-height: 130px;
    margin: -50px auto 0;
    border-radius: 50%;
    overflow: hidden;
    padding: 0;
    box-shadow: 0 16px 38px -12px rgba(0,0,0,.56), 0 4px 25px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(0,0,0,.2);
}

.card-profile .card-avatar img{
    width: 100%;
}
.card-profile .card-avatar+.card-body{
    margin-top: 15px;
}


.btn:not(.btn-just-icon){
    position: relative;
    padding: 12px 30px !important;
    margin: .3125rem 1px;
   font-size: .75rem;
    font-weight: 400 !important;
    line-height: 1.428571;
    text-decoration: none;
    text-transform: uppercase;
    letter-spacing: 0;
    cursor: pointer;
    background-color: transparent;
    border: 0;
    border-radius: .2rem;
    outline: 0;
}
.btn.btn-just-icon.btn-round {
    border-radius: 50%;
    margin:.3125rem 1px;
}
.btn.btn-twitter {
    color: #fff;
    background-color: #55acee;
    border-color: #55acee;
    box-shadow: 0 2px 2px 0 rgba(85,172,238,.14), 0 3px 1px -2px rgba(85,172,238,.2), 0 1px 5px 0 rgba(85,172,238,.12);
}

.btn.btn-twitter.btn-link{
    background-color: transparent;
    color: #55acee;
    box-shadow: none;
}

.btn.btn-twitter.btn-link:hover:active{
    background-color: transparent;
    color: #55acee;
    box-shadow: none;
}

.btn.btn-twitter.btn-link:hover{
    box-shadow: none;
    background-color: transparent;
    color: #55acee;
}

.btn.btn-twitter:hover{
    background-color: #55acee;
    color: #fff;
    box-shadow: 0 14px 26px -12px rgba(85,172,238,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(85,172,238,.2);
}

.btn.btn-twitter:hover:active{
    background-color: #55acee;
    color: #fff;
    box-shadow: 0 14px 26px -12px rgba(85,172,238,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(85,172,238,.2);
}

.btn.btn-twitter:active{
    background-color: #55acee;
    color: #fff;
    box-shadow: 0 14px 26px -12px rgba(85,172,238,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(85,172,238,.2);
}

.btn.btn-twitter:focus{
    background-color: #55acee;
    color: #fff;
    box-shadow: 0 14px 26px -12px rgba(85,172,238,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(85,172,238,.2);
}

.btn.btn-facebook {
    color: #fff;
    background-color: #3b5998;
    border-color: #3b5998;
    box-shadow: 0 2px 2px 0 rgba(59,89,152,.14), 0 3px 1px -2px rgba(59,89,152,.2), 0 1px 5px 0 rgba(59,89,152,.12);
}

.btn.btn-facebook:hover {
    background-color: #3b5998;
    color: #fff;
    box-shadow: 0 14px 26px -12px rgba(59,89,152,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(59,89,152,.2);
}

.btn.btn-facebook:hover:active {
    background-color: #3b5998;
    color: #fff;
    box-shadow: 0 14px 26px -12px rgba(59,89,152,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(59,89,152,.2);
}

.btn.btn-facebook:active {
    background-color: #3b5998;
    color: #fff;
    box-shadow: 0 14px 26px -12px rgba(59,89,152,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(59,89,152,.2);
}

.btn.btn-facebook:focus {
    background-color: #3b5998;
    color: #fff;
    box-shadow: 0 14px 26px -12px rgba(59,89,152,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(59,89,152,.2);
}

.btn.btn-dribbble.btn-link{
    background-color: transparent;
    color: #ea4c89;
}

.btn.btn-dribbble.btn-link:hover:active{
    background-color: transparent;
    color: #ea4c89;
}

.btn.btn-instagram.btn-link{
    background-color: transparent;
    color: #125688;
}
.btn.btn-instagram.btn-link:hover:active{
    background-color: transparent;
    color: #125688;
}

.btn.btn-google {
    color: #fff;
    background-color: #dd4b39;
    border-color: #dd4b39;
    box-shadow: 0 2px 2px 0 rgba(221,75,57,.14), 0 3px 1px -2px rgba(221,75,57,.2), 0 1px 5px 0 rgba(221,75,57,.12);
}

.btn.btn-google:hover{
    color: #fff;
    background-color: #dd4b39;
    box-shadow: 0 14px 26px -12px rgba(221,75,57,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(221,75,57,.2);
}

.btn.btn-google:active{
    color: #fff;
    background-color: #dd4b39;
    box-shadow: 0 14px 26px -12px rgba(221,75,57,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(221,75,57,.2);
}

.btn.btn-google:hover:active{
    color: #fff;
    background-color: #dd4b39;
    box-shadow: 0 14px 26px -12px rgba(221,75,57,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(221,75,57,.2);
}

.btn.btn-google:focus{
    color: #fff;
    background-color: #dd4b39;
    box-shadow: 0 14px 26px -12px rgba(221,75,57,.42), 0 4px 23px 0 rgba(0,0,0,.12), 0 8px 10px -5px rgba(221,75,57,.2);
}

.btn.btn-info {
    color: #fff !important;
    background-color: #00bcd4 !important;
    border-color: #00bcd4 !important;
    box-shadow: 0 2px 2px 0 rgba(0,188,212,.14), 0 3px 1px -2px rgba(0,188,212,.2), 0 1px 5px 0 rgba(0,188,212,.12);
}

.btn.btn-round {
    border-radius: 30px;
}
/* End Events and Members */


 </style>
 <style>
    .md-avatar {
vertical-align: middle;
width: 50px;
height: 50px;
}
.md-avatar.size-1 {
width: 40px;
height: 40px;
}
.md-avatar.size-2 {
width: 70px;
height: 70px;
}
.md-avatar.size-3 {
width: 90px;
height: 90px;
}
.md-avatar.size-4 {
width: 110px;
height: 110px;
}

/*    */

body{
  margin-top: auto;
    background-color: #f1f1f1;
  }
  .border{
    border-bottom:1px solid #F1F1F1;
    margin-bottom:10px;
  }
  .main-secction{
    box-shadow: 10px 10px 10px;
  }
  .image-section{
    padding: 0px;
  }
  .image-section img{
    width: 100%;
    height:250px;
    position: relative;
  }
  .user-image{
    position: absolute;
    margin-top:-50px;
  }
  .user-left-part{
    margin: 0px;
  }
  .user-image img{
    width:100px;
    height:100px;
  }
  .user-profil-part{
    padding-bottom:30px;
    background-color:#FAFAFA;
  }
  .follow{    
    margin-top:70px;   
  }
  .user-detail-row{
    margin:0px; 
  }
  .user-detail-section2 p{
    font-size:12px;
    padding: 0px;
    margin: 0px;
  }
  .user-detail-section2{
    margin-top:10px;
  }
  .user-detail-section2 span{
    color:#7CBBC3;
    font-size: 20px;
  }
  .user-detail-section2 small{
    font-size:12px;
    color:#D3A86A;
  }
  .profile-right-section{
    padding: 20px 0px 10px 15px;
    background-color: #FFFFFF;  
  }
  .profile-right-section-row{
    margin: 0px;
  }
  .profile-header-section1 h1{
    font-size: 25px;
    margin: 0px;
  }
  .profile-header-section1 h5{
    color: #0062cc;
  }
  .req-btn{
    height:30px;
    font-size:12px;
  }
  .profile-tag{
    padding: 10px;
    border:1px solid #F6F6F6;
  }
  .profile-tag p{
    font-size: 12px;
    color:black;
  }
  .profile-tag i{
    color:#ADADAD;
    font-size: 20px;
  }
  .image-right-part{
    background-color: #FCFCFC;
    margin: 0px;
    padding: 5px;
  }
  .img-main-rightPart{
    background-color: #FCFCFC;
    margin-top: auto;
  }
  .image-right-detail{
    padding: 0px;
  }
  .image-right-detail p{
    font-size: 12px;
  }
  .image-right-detail a:hover{
    text-decoration: none;
  }
  .image-right img{
    width: 100%;
  }
  .image-right-detail-section2{
    margin: 0px;
  }
  .image-right-detail-section2 p{
    color:#38ACDF;
    margin:0px;
  }
  .image-right-detail-section2 span{
    color:#7F7F7F;
  }

  .nav-link{
    font-size: 1.2em;    
  }
  

/* START Product Items Slider  */
  .gallery-wrap .img-big-wrap img {
    height: 450px;
    width: auto;
    display: inline-block;
    cursor: zoom-in;
}


.gallery-wrap .img-small-wrap .item-gallery {
    width: 60px;
    height: 60px;
    border: 1px solid #ddd;
    margin: 7px 2px;
    display: inline-block;
    overflow: hidden;
}

.gallery-wrap .img-small-wrap {
    text-align: center;
}
.gallery-wrap .img-small-wrap img {
    max-width: 100%;
    max-height: 100%;
    object-fit: cover;
    border-radius: 4px;
    cursor: zoom-in;
}
/*  Product Items Slider END */

/* Limited Charaters in EVENTS Menu */

/* Matrimony Profile Card */
/*  Profile START */
/*  Profile START */
/* User Cards */
.user-box {
    width: 110px;
    margin: auto;
    margin-bottom: 20px;
    
}

.user-box img {
    width: 100%;
    border-radius: 50%;
	padding: 3px;
	background: #fff;
	-webkit-box-shadow: 0px 5px 25px 0px rgba(0, 0, 0, 0.2);
    -moz-box-shadow: 0px 5px 25px 0px rgba(0, 0, 0, 0.2);
    -ms-box-shadow: 0px 5px 25px 0px rgba(0, 0, 0, 0.2);
    box-shadow: 0px 5px 25px 0px rgba(0, 0, 0, 0.2);
}

.profile-card-2 .card {
	position:relative;
}

.profile-card-2 .card .card-body {
	z-index:1;
	

}

.profile-card-2 .card::before {
    content: "";
    position: absolute;
    top: 0px;
    right: 0px;
    left: 0px;
	border-top-left-radius: .25rem;
    border-top-right-radius: .25rem;
    height: 112px;
    background-color: #e6e6e6;
}

.profile-card-2 .card.profile-primary::before {
	background-color: #008cff;
}
.profile-card-2 .card.profile-success::before {
	background-color: #15ca20;
}
.profile-card-2 .card.profile-danger::before {
	background-color: #fd3550;
}
.profile-card-2 .card.profile-warning::before {
	background-color: #ff9700;
}
.profile-card-2 .user-box {
	margin-top: 30px;
}

.profile-card-3 .user-fullimage {
	position:relative;
}

.profile-card-3 .user-fullimage .details{
	position: absolute;
    bottom: 0;
    left: 0px;
	width:100%;
}

.profile-card-4 .user-box {
    width: 110px;
    margin: auto;
    margin-bottom: 10px;
    margin-top: 15px;
}

.profile-card-4 .list-icon {
    display: table-cell;
    font-size: 30px;
    padding-right: 20px;
    vertical-align: middle;
    color: #223035;
}

.profile-card-4 .list-details {
	display: table-cell;
	vertical-align: middle;
	font-weight: 600;
    color: #000;
    font-size: 15px;
    line-height: 15px;
    font-family: 'Sen', sans-serif;
}

.profile-card-4 .list-details small{
	display: table-cell;
	vertical-align: middle;
	font-size: 15px;
	font-weight: 600;
    color: #000;
    font-family: 'Sen', sans-serif;
}



.z-depth-3 {
    -webkit-box-shadow: 0 11px 7px 0 rgba(0,0,0,0.19),0 13px 25px 0 rgba(0,0,0,0.3);
    box-shadow: 0 11px 7px 0 rgba(0,0,0,0.19),0 13px 25px 0 rgba(0,0,0,0.3);
}

/*  Profile END */

    .timeline {
    list-style-type: none;
    margin-left: -100px;  /* changed margin 0 to margin-left: -100px  */
    padding: 0;
    position: relative
}

.timeline:before {
    content: '';
    position: absolute;
    top: 5px;
    bottom: 5px;
    width: 1px;
    background: grey;
    left: 20%;
    margin-left: -2.5px
}

.timeline>li {
    position: relative;
    min-height: 50px;
    padding: 20px 0
}

.timeline .timeline-time {
    position: absolute;
    left: 0;
    width: 18%;
    text-align: right;
    top: 30px
}

.timeline .timeline-time .date,
.timeline .timeline-time .time {
    display: block;
    font-weight: 600
}

.timeline .timeline-time .date {
    line-height: 16px;
    font-size: 12px
}

.timeline .timeline-time .time {
    line-height: 24px;
    font-size: 20px;
    color: #242a30
}

.timeline .timeline-icon {
   left: 15%;
    position: absolute;
    width: 10%;
    text-align: center;
    top: 40px
}

.timeline .timeline-icon a {
    text-decoration: none;
    width: 20px;
    height: 20px;
    display: inline-block;
    border-radius: 20px;
    background: #d9e0e7;
    line-height: 10px;
    color: #fff;
    font-size: 14px;
    border: 5px solid #2d353c;
    transition: border-color .2s linear
}

.timeline .timeline-body {
    margin-left: 23%;
    margin-right: 17%;
    background: #fff;
    position: relative;
    padding: 20px 25px;
    border-radius: 6px
}

.timeline .timeline-body:before {
    content: '';
    display: block;
    position: absolute;
    border: 10px solid transparent;
    border-right-color: #fff;
    left: -20px;
    top: 20px
}

.timeline .timeline-body>div+div {
    margin-top: 15px
}

.timeline .timeline-body>div+div:last-child {
    margin-bottom: -20px;
    padding-bottom: 20px;
    border-radius: 0 0 6px 6px
}

.timeline-header {
    padding-bottom: 10px;
    border-bottom: 1px solid #e2e7eb;
    line-height: 30px
}

.timeline-header .userimage {
    float: left;
    width: 34px;
    height: 34px;
    border-radius: 40px;
    overflow: hidden;
    margin: -2px 10px -2px 0
}

.timeline-header .username {
    font-size: 16px;
    font-weight: 600
}

.timeline-header .username,
.timeline-header .username a {
     color:#000; 
    font-size:18px;font-weight:500; 
    font-family: 'Sen', sans-serif;
}

.timeline img {
    max-width: 100%;
    display: block
}

.timeline-content {
    letter-spacing: .25px;
    line-height: 18px;
    font-size: 13px
}

  .timeline-content p{
     color:#000; 
    font-size:18px;font-weight:500; 
    font-family: 'Sen', sans-serif;
    }

.timeline-content:after,
.timeline-content:before {
    content: '';
    display: table;
    clear: both
}

.timeline-title {
    margin-top: 0
}

.timeline-footer {
    background: #fff;
    border-top: 1px solid #e2e7ec;
    padding-top: 15px
}

.timeline-footer a:not(.btn) {
    color: #575d63
}

.timeline-footer a:not(.btn):focus,
.timeline-footer a:not(.btn):hover {
    color: #2d353c
}

.timeline-likes {
    color: #6d767f;
    font-weight: 600;
    font-size: 12px
}

.timeline-likes .stats-right {
    float: right
}

.timeline-likes .stats-total {
    display: inline-block;
    line-height: 20px
}

.timeline-likes .stats-icon {
    float: left;
    margin-right: 5px;
    font-size: 9px
}

.timeline-likes .stats-icon+.stats-icon {
    margin-left: -2px
}

.timeline-likes .stats-text {
    line-height: 20px
}

.timeline-likes .stats-text+.stats-text {
    margin-left: 15px
}

.timeline-comment-box {
    background: #f2f3f4;
    margin-left: -25px;
    margin-right: -25px;
    padding: 20px 25px
}

.timeline-comment-box .user {
    float: left;
    width: 34px;
    height: 34px;
    overflow: hidden;
    border-radius: 30px
}

.timeline-comment-box .user img {
    max-width: 100%;
    max-height: 100%
}

.timeline-comment-box .user+.input {
    margin-left: 44px
}


/* Matrimony Profile Card End */


/*  Create Form New Design in Events menu  */
.page-content {
	width: 100%;
	margin:  0 auto;
//	background: red;
	display: flex;
	display: -webkit-flex;
	justify-content: center;
	-o-justify-content: center;
	-ms-justify-content: center;
	-moz-justify-content: center;
	-webkit-justify-content: center;
	align-items: center;
	-o-align-items: center;
	-ms-align-items: center;
	-moz-align-items: center;
	-webkit-align-items: center;
    margin-top:-160px;
}
.form-v5-content  {
	background: #f5f5f5;  /* f5f5f5 */
    /* //background-color: rgb(47, 115, 200); */
	width: 670px;
	border-radius: 8px;
	-o-border-radius: 8px;
	-ms-border-radius: 8px;
	-moz-border-radius: 8px;
	-webkit-border-radius: 8px;
	margin: 175px 0;
	font-family: 'Sen', sans-serif;
	color: #333;
	font-weight: 400;
	position: relative;
	font-size: 18px;
    border: 1px solid lightskyblue;
    box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.2);
	-o-box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.2);
	-ms-box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.2);
	-moz-box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.2);
	-webkit-box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.2);
}
.form-v5-content .form-detail {
	padding: 30px 45px 30px 45px;
	position: relative;
}
.form-detail h2 {
	font-weight: 700;
	font-size: 25px;
	text-align: center;
	position: relative;
	padding: 3px 0 20px;
	margin-bottom: 40px;
}
.form-detail h2::after {
	background: #3786bd;
	width: 50px;
	height: 2px;
	content: "";
	position: absolute;
	top: 100%;
	left: 50%;
    transform: translateX(-50%);
    -o-transform: translateX(-50%);
	-ms-transform: translateX(-50%);
	-moz-transform: translateX(-50%);
	-webkit-transform: translateX(-50%);
}
.form-detail .form-row {
	position: relative;
}
.form-detail .form-row-last {
	text-align: center;
}
.form-detail label {
	display: block;
	font-size: 18px;
	padding-bottom: 10px;
}
.form-detail .input-text {
	margin-bottom: 26px;
}
.form-detail .input-text1 {
	margin-bottom: 26px;
}
.form-detail input {
	width: 94.5%;
    padding: 10.5px 15px;
    border: 1px solid #e5e5e5;
    appearance: unset;
    -moz-appearance: unset;
    -webkit-appearance: unset;
    -o-appearance: unset;
    -ms-appearance: unset;
    outline: none;
    -moz-outline: none;
    -webkit-outline: none;
    -o-outline: none;
    -ms-outline: none;
    border-radius: 4px;
	-o-border-radius: 4px;
	-ms-border-radius: 4px;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	font-family: 'Sen', sans-serif;
	font-weight: 400;
	font-size: 18px;
}
.form-detail textarea {
	width: 94.5%;
    padding: 10.5px 15px;
    border: 1px solid #e5e5e5;
    appearance: unset;
    -moz-appearance: unset;
    -webkit-appearance: unset;
    -o-appearance: unset;
    -ms-appearance: unset;
    outline: none;
    -moz-outline: none;
    -webkit-outline: none;
    -o-outline: none;
    -ms-outline: none;
    border-radius: 4px;
	-o-border-radius: 4px;
	-ms-border-radius: 4px;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	font-family: 'Sen', sans-serif;
	font-weight: 400;
	font-size: 18px;
}
.form-detail select {
	width: 94.5%;
    padding: 10.5px 15px;
    border: 1px solid #e5e5e5;
    appearance: unset;
    -moz-appearance: unset;
    -webkit-appearance: unset;
    -o-appearance: unset;
    -ms-appearance: unset;
    outline: none;
    -moz-outline: none;
    -webkit-outline: none;
    -o-outline: none;
    -ms-outline: none;
    border-radius: 4px;
	-o-border-radius: 4px;
	-ms-border-radius: 4px;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	font-family: 'Sen', sans-serif;
	font-weight: 400;
	font-size: 18px;
}

.form-detail input:focus {
	border: 1px solid #b3b3b3;
}
.form-detail .register {
	font-size: 18px;
	color: #fff;
	background: #3786bd;
	border-radius: 5px;
	-o-border-radius: 5px;
	-ms-border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;
	width: 180px;
	box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.2);
	-o-box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.2);
	-ms-box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.2);
	-moz-box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.2);
	-webkit-box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.2);
	border: none;
	margin: 19px 0 40px;
	cursor: pointer;
}
.form-detail .register:hover {
	background: #2f73a3;
}
.form-detail .form-row-last input {
	padding: 14px;
}
.form-detail i {
	font-size: 14px;
	color: #999;
	right: 15px;
	top: 50%;
	transform: translateX(-50%);
	position: absolute;
}
input::-webkit-input-placeholder { /* Chrome/Opera/Safari */
  color: #999;
  font-size: 18px;
}
input::-moz-placeholder { /* Firefox 19+ */
  color: #999;
  font-size: 18px;
}
input:-ms-input-placeholder { /* IE 10+ */
  color: #999;
  font-size: 16px;
}
input:-moz-placeholder { /* Firefox 18- */
  color: #999;
  font-size: 18px;
}

/* Responsive */
@media screen and (max-width: 767px) {
	.form-v5-content {
	    margin: 175px 20px;
	}
}
/* END Create Form New Design in Events menu  */

/* WELCOME PAGE Top after Slider show */
.homecard {
   /* background: #fff; */
    margin-bottom: 30px;
    transition: .5s;
    border-radius: 10px;
    display: inline-block;
    position: relative;
    width: 100%;
  /*  box-shadow: 5px 10px 18px #888888;  commented 05052021 */
    margin-left: 2px !important;
    
}
.homecard .body {
    font-size: 14px;
    color: #424242;
    padding: 20px;
    font-weight: 400;
}
.homeprofile-page .homeprofile-header {
    position: relative
}

.homeprofile-page .homeprofile-header .homeprofile-image img {
    width:100%;
    height:100%;
    border: 3px solid #fff;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23)
    
}

/*  END WELCOME PAGE TOP AFTER SLIDER SHOW */
/*  MATRIMONY CSS BEGINING */
.matrimonycard {
    background: #fff;
    margin-bottom: 30px;
    transition: .5s;
    border-radius: 10px;
    display: inline-block;
    position: relative;
    width: 100%;
    box-shadow: 5px 10px 18px #888888;
    
}
.matrimonycard .body {
    font-size: 14px;
    color: #424242;
    padding: 20px;
    font-weight: 400;
}
.matrimonyprofile-page .matrimonyprofile-header {
    position: relative
}

/*  END MATRIMONY  */

 /* Activities Services*/
         .right_slide_act{  
              color: #000;
              margin-top: -207px;
              margin-left: 1263px;
              position: absolute;
              border: 1px solid white;
              border-width: 16px;
              border-radius: 50%;
              box-shadow: -2px 1px 15px 0 rgba(0,0,0,.16);
            }
            
            .left_slide_act{
              margin-top: -195px;
              margin-left: -690px;
              position: absolute;
              border: 1px solid white;
              border-width: 16px;
              border-radius: 50%;
              box-shadow: -2px 1px 15px 0 rgba(0,0,0,.16);
            }
       /* End  Activities Services*/
 </style>


   <!-- Include Events and Members IMP -->
<!-- Include Events and Members IMP -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-material-design@4.1.1/dist/css/bootstrap-material-design.min.css">
    <!--<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" rel="stylesheet"> -->
   <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons">
    
    <script>
    $(document).ready(function() {
        $('body').bootstrapMaterialDesign();
    });</script>  <!-- End Include Events and Members -->


 @stack('css')   {{--Any styles you 'push' will go here --}}


</head>
<body>
    <div id="app">

     @include('inc.navbar')

    <main > <br/><!-- class="py-4"  -->
            @yield('content')
        </main>
    </div>

    @include('inc.footer')
    <!-- JS Files -->
     <script src="{{ asset('js/frontend_js/vendor/jquery-3.2.1.min.js') }}"></script> 
     <script src="{{ asset('js/frontend_js/popper.min.js') }}"></script>
    <script src="{{ asset('js/frontend_js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/frontend_js/plugins.js') }}"></script>
    <script src="{{ asset('js/frontend_js/active.js') }}"></script> 
<!-- FlexSlider -->
        <script src="{{ asset('js/jquery.toast.js') }}"></script>

<!-- Begin emoji-picker JavaScript -->
    <script src="{{ asset('js/frontend_js/lib/js/config.js')}}"></script>
    <script src=" {{ asset('js/frontend_js/lib/js/util.js')}}"></script>
    <script src="{{ asset('js/frontend_js/lib/js/jquery.emojiarea.js')}}"></script>
    <script src="{{ asset('js/frontend_js/lib/js/emoji-picker.js')}}"></script> 
<!-- End emoji-picker JavaScript -->
<!-- START emojiPicker -->
<script>
  $(function() {
    // Initializes and creates emoji set from sprite sheet
    window.emojiPicker = new EmojiPicker({
      emojiable_selector: '[data-emojiable=true]',
      assetsPath: 'https://www.tecpleglobal.com/emoji-img',
      popupButtonClasses: 'fa fa-smile-o'
    });
    // Finds all elements with `emojiable_selector` and converts them to rich emoji input fields
    // You may want to delay this step if you have dynamically created input fields that appear later in the loading process
    // It can be called as many times as necessary; previously converted input fields will not be converted again
    window.emojiPicker.discover();
  });
</script>
<!-- END emojiPicker -->


	  <script type="text/javascript">
		$(function(){
		  SyntaxHighlighter.all();
		});
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	  </script>
<!-- FlexSlider -->		


</body>
</html>
