 @foreach($comments as $faqcomment)
    <div class="display-comment">
        <div class="row">
             
                        <div class="col-lg-2 col-12" >  
                                <a href="{{ route('profile.index',$faqcomment->id) }}">
                                         <img src="{{$faqcomment->User_Photo}}" width="80" height="80"  class="rounded-circle" />               
                                </a>
                        </div> 
               
  
                <div class="col-lg-10 col-12 order-1 order-lg-1 md-mt-40 sm-mt-40"  > 
                        <div class="row">
                               <!--  <p style="max-width:150px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-weight:900;"> </p> -->
                               <div class="col-lg-8 col-8">
                                         <a href="{{ route('profile.index',$faqcomment->id) }}">
                                            {{ $faqcomment->name }} 
                                        </a>
                                </div>
                                <div class="col-lg-2 col-2">
                                         <text class="pull-right"> {{$faqcomment->created_at}} </text>
                                </div>
                        </div>
                        <div class="row"  style="margin-left:0px">
                                 {{ $faqcomment->Comment_Body }}
                        </div>
                      
                </div>
        </div>
        <hr/>
           
        
   </div>
@endforeach