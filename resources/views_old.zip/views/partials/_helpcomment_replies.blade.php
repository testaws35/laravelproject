
@foreach($comments as $comment)
    <div class="display-comment">
        <div class="row">
           
           
           <div class="col-lg-2 col-12" >  
                                <a href="{{ route('profile.index',$comment->userid) }}">
                                         <img src="{{$comment->photo}}" width="80" height="80"  class="rounded-circle" />               
                                </a>
           </div> 
           <div class="col-lg-10 col-12 order-1 order-lg-1 md-mt-40 sm-mt-40"  > 
                        <div class="row">
                                 <div class="col-lg-8 col-8">
                                         <a href="{{ route('profile.index',$comment->userid) }}">
                                            {{ $comment->name }} 
                                        </a>
                                </div>
                                <div class="col-lg-2 col-2">
                                         <text class="pull-right"> {{$comment->created_at}} </text>
                                </div>
                        </div>
                        <div class="row"  style="margin-left:0px">
                                 {{ $comment->Description}}
                        </div>
                      
        </div>
                
        
    </div>
@endforeach