@extends('layouts.app1')
@section('content')

<!-- End Bradcaump area -->
<div class="page-blog-details section-padding--lg bg--white">
        <div class="container">
               
            <div class="row">
                   
                <div class="col-lg-9 col-12">
                    <div class="blog-details content">
                        <article class="blog-post-details">
                            <div class="post-thumbnail">
                            <h2 class="text-center" style="font-family: 'Sen', sans-serif;margin-top:-79px;"><b>{{ $sangammeeting->Title }}</b><a href="{{ route('sangammeetings.index') }}" class="pull-left" title="Back to Sangam Meetings"><b style="font-size:10px;"><i class="fa fa-arrow-left fa-3x"></i></b></a> </h2>
                            <div class="blog-date-categori">
                               </div>
                               
                                <div class="card-header card-header-image">
                                         <a href="#">
                                        <img class="img-thumbnail" src="{{ $sangammeeting->Photo }}" style="max-height: 300px;width:90%;margin-top:50px;">
                                          </a>
                                          <div class="colored-shadow" style="background-image: url('{{ $sangammeeting->Photo }}');opacity: 1;">
                                         </div>
                                </div>
                            </div>

                            <div class="post_wrapper">
                                <div class="post_header">
                                    <h2><!-- {{ $sangammeeting->Title }} -->   
                                         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   
                                         <?php if(  (Auth::user()->userroleID==2) ||  (  ( $sangammeeting->Createdby == Auth::user()->id)  )  )   {  ?>
                                          {{--  /*  &&
                                             ( ($sangammeeting->CreatedOn  > date('Y-m-d', strtotime(' - 30 days'))  ) && ($announcement->CreatedOn <= date('Y-m-d'))  ) )  */ --}}
                                            
                                                    <a href="{{ route('sangammeetings.edit',$sangammeeting->SangamMeetingID) }}" class="pull-center"><b style="font-size:10px;"><i class="fas fa-user-edit fa-3x" title="Edit Sangam Meeting"></i> </b></a> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 

                                                    <a   href="{{ route('sangammeetings.destroy',$sangammeeting->SangamMeetingID) }}"   class="pull-right ml-5">
                                                                <i class="fa fa-trash fa-2x" aria-hidden="true"></i>
                                                    </a>             
                                         <?php }?> 
                                         
                                    </h2>
                                    <div class="blog-date-categori">
                                            <ul>
                                            <li class="text-uppercase">Meeting Date: {{ date('d-M-Y', strtotime($sangammeeting->MeetingDate )) }}
                                            </li>
                                            
                                            </ul>

                                            <ul>
                                            <li>Posted By : {{ $sangammeeting->name }}
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <hr/>
                                <div class="post_content">
                                    <p><b class="text-uppercase">Description:</b> <br/> {{ $sangammeeting->Meeting_Content }}</p>
                                </div>
                                <hr/>
                            </div>
                        </article>
                      </div>
                </div>
                <div class="col-lg-3 col-12 md-mt-40 sm-mt-40">
                    <div class="wn__sidebar">
                      
                        <!-- Start Single Widget -->
                        <aside class="widget recent_widget">
                            <h3 class="widget-title">Recent Meetings</h3>
                            <div class="recent-posts">
                                <ul>
                                    <li>
                                            @foreach ($sangammeetings->take(5) as $sangammeeting)
                                                    <div class="thumb" style="max-width:900px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"> 
                                                        
                                                @if($sangammeeting->Photo )
                                                  <a href="{{ route('sangammeetings.show',$sangammeeting->SangamMeetingID) }}" style="text-decoration:none;">
                                                       <img src="{{ $sangammeeting->Photo }}"  alt="sangammeetings" class="rounded-circle"  width="50" height="50">
                                                       &nbsp; {{ $sangammeeting->Title }}  </a>
                                                    @else 
                                                    <img class="img-thumbnail" src="/images/frontend_images/avatar.png" alt="sangammeetings" class="rounded-circle"  width="50" height="50">
                                                   @endif     
                                                  
                                                       <hr>
                                             @endforeach
                                    </li>
                                </ul>
                            </div>
                        </aside>
                        <!-- End Single Widget -->
                          <!-- Start Archives Widget -->
                        <aside class="wedget__categories poroduct--cat">
                            <h3 class="wedget__title"><b>Archives </b></h3>
                            <ul>
                                <li><a href="{{ url('/sangammeetings/?mon=1') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 1 months')  ) ); ?></a></li>
                                <li><a href="{{ url('/sangammeetings/?mon=2') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 2 months')  ) ); ?></a></li>
                                <li><a href="{{ url('/sangammeetings/?mon=3') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 3 months')  ) ); ?></a></li>
                                <li><a href="{{ url('/sangammeetings/?mon=4') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 4 months')  ) ); ?></a></li>
                                <li><a href="{{ url('/sangammeetings/?mon=5') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 5 months')  ) ); ?></a></li>
                                <li><a href="{{ url('/sangammeetings/?mon=6') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 6 months')  ) ); ?></a></li>
                            
                            </ul>
                        </aside>
                      <!-- End Archives Widget -->
                      </div>
                </div>
                
            </div><!-- END ROW-->
         </div>
    </div>

    @include('sweetalert::alert')
@endsection
