@extends('layouts.app1')
@section('content')

<!DOCTYPE html>

<html>

<head>

    <title>Temple Functions </title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <style type="text/css">

    /* Limiting column data */
        .mytable p{
    max-width:900px; /* Customise it accordingly */
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    }
   
    .mytable h4{
    max-width:280px; /* Customise it accordingly */
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    }

    /* END Limiting column data */
     </style>

<!-- ToolTip Script   -->
<script>
    $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();   
    });
    </script>
<!-- END ToolTip Script   -->

</head>

<body>

  

<!-- Start Shop Page -->
<div class="page-shop-sidebar left--sidebar bg--white section-padding--lg" style="margin-top:-100px;">
<!-- Container -->
    <div class="container">
               <!--- ********** Outer row Area***********************************
               ********************************************************-->

              <div class="row">  <!-- outer row -->

                                <!--- ********** 1st column Area***********************************
                            ********************************************************-->
                            
                            <div class="col-lg-3 col-12 order-2 order-lg-1 md-mt-40 sm-mt-40">

                                <div class="row"> <!-- begin  1 col row -->
                                        <div class="shop__sidebar">
                                                <?php if (isset($temples) ) {  ?>
                                                <aside class="wedget__categories poroduct--cat">
                                                        <h3 class="wedget__title tempfun_wise"><b>@lang('home.templefunc_index_lhstemplewise')</b></h3>

                                                        <form id="prodindex" >
                                                            <!--Aruna added  Either you can use a hidden control and set its value as csrf_token()  
                                                                            or use csrffield like below 0r simply use atsymbolcsrf. This is necessary to pass data between HTML and PHP -->
                                                                            {!! csrf_field() !!}
                                                                        <ul class="properties-filter">
                                                                                    @foreach ($temples as $temple)
                                                                                    <li  class="selected" name="{{$temple->TempleID}}" id="templeid" >
                                                                                        <a href="?templeid={{$temple->TempleID}}" data-filter="{{$temple->TempleID}}" class="click"> {{ Illuminate\Support\Str::limit(ucwords($temple->Temple_Name), 20, $end='...') }}   </a>
                                                                                    </li> 
                                                                                    @endforeach
                                                                        </ul>
                                                        </form>
                                            </aside>
                                            <?php } ?>
                                            
                                        </div>
                                </div>

                    <!--- ********** second row in 1st column Area***********************************
                    ********************************************************-->
                     
                       <div class="row">
                           <aside class="wedget__categories poroduct--cat">
                               <h3 class="wedget__title tempfun_faq"><b>@lang('home.templefunc_index_lhscufaq') </b></h3>
                                     <ul>
                                         <li><a href="{{ url('/templefunctions/') }}">@lang('home.templefunc_index_lhscumonth') </li>
                                     </ul>
                               </h3>
                           </aside>
                       </div>
               <!-- Start search_widget Widget -->
                       <!-- <div class="row">
                        <aside class="widget search_widget">
                                <h3 class="wedget-title"><b>Search </b></h3>
                                <form action="#">
                                    <div class="form-input">
                                        <input type="text" placeholder="Search...">
                                        <button><i class="fa fa-search"></i></button>
                                    </div>
                                </form>
                            </aside> 
                        </div> -->
                    <!-- End search_widget Widget -->


                       <div class="row">
                            

                               <!-- Start Single Widget -->
                               <aside class="wedget__categories poroduct--cat">
                                   <h3 class="wedget__title tempfun_arc"><b>@lang('home.templefunc_index_lhsarch') </b></h3>
                                   <ul>
                                       <li><a href="{{ url('/templefunctions/?mon=1') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 1 months')  ) ); ?></a></li>
                                       <li><a href="{{ url('/templefunctions/?mon=2') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 2 months')  ) ); ?></a></li>
                                       <li><a href="{{ url('/templefunctions/?mon=3') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 3 months')  ) ); ?></a></li>
                                       <li><a href="{{ url('/templefunctions/?mon=4') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 4 months')  ) ); ?></a></li>
                                       <li><a href="{{ url('/templefunctions/?mon=5') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 5 months')  ) ); ?></a></li>
                                       <li><a href="{{ url('/templefunctions/?mon=6') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 6 months')  ) ); ?></a></li>
                                     
                                   </ul>
                               </aside>
                               <!-- End Single Widget -->
                              
                       </div>

     </div> <!-- end  1 col row -->
        <!--- ********** 2nd column Area***********************************
        ********************************************************-->

       <div class="col-lg-9 col-12 order-1 order-lg-2">
         <div class="tab__container">
           <div class="shop-grid tab-pane fade show active" id="nav-grid" role="tabpanel">

            <!-- Row  -->
            <div class="row">
                <div class="title">
                <h1 class="font-bold text-center text-uppercase temp_heading" >@lang('home.templefunc_index_head')
                @if(\Auth::user()->UserroleID==2 || Auth::user()->IsTempleMember==1)
                          <a class="btn fa-3x" style="background: #f82249;font-family: 'Sen', sans-serif;color:#fff;border-bottom-right-radius:25px;border-top-left-radius:25px;" href="{{ route('templefunctions.create') }}"><b style="font-size:20px;font-family: 'Sen', sans-serif;"><i class="fas fa-upload fa-1x" data-toggle="tooltip" data-placement="top" title="Upload Temple Functions"></i></b></a>
                         
                
                 @endif
                </h1>   
                  
                </div>
            </div>  <!--row end -->
             
            <!-- Row  -->
            <div class="row">
                <!--- ********** Elders List Area***********************************
                   ********************************************************-->
               <?php if (isset($templefunctions)   && (count($templefunctions) >0 )  )  { ?>   
                 
                    @foreach ($templefunctions as $templefunction)
                        <div class="col-md-4">
                                <div class="card card-profile">
                                    <div class="card-header card-header-image">
                                        <a href="{{ route('templefunctions.show',$templefunction->TempleFunctionID) }}">
                                            <img class="img" src="{{ $templefunction->Photo }}">
                                        </a>
                                        <div class="colored-shadow" style="background-image: url('{{ $templefunction->Photo }}');opacity: 1;">
                                        </div>
                                
                                    </div>
                                
                                    <div class="card-body mytable ">
                                        <h4 class="card-title">{{ $templefunction->Title }}  {{--&nbsp;&nbsp;&nbsp;  <span> {{ $templefunction->FunctionDate }}</span>--}}</h4> 
                                        <p style="font-family: 'Sen', sans-serif;font-size:16px;">
                                                {{ $templefunction->Function_Content }}  
                                        </p> 
                                        <a href="{{ route('templefunctions.show',$templefunction->TempleFunctionID) }}" class="btn" style="background: #f82249;font-family: 'Sen', sans-serif;color:#fff;border-bottom-right-radius:25px;border-top-left-radius:25px;font-size:14px;">@lang('home.templefunc_index_readmorebtn')</a> <br/><br/>
                                    </div>
                                </div>
                        </div>
                        @endforeach
                    <?php } else{ ?>
                                    <br>  <br>
                                   
                                    <p><h4 class="alert alert-info templefun_alertfailed">   {{$Failed}}</h4> </p>
                    <?php }   ?>

                </div><!-- Row END -->
            
             </div>  <!-- end of inner row-->
          </div>
       </div>
     </div>  <!-- end second column-->

                   

           <!--- ********** End Outer row ***********************************
           ********************************************************-->
          </div><!-- END Outer  ROW -->
    </div><!-- Container END -->
 </div>    <!-- End Shop Page -->

</body>     
</html>
@include('sweetalert::alert')

@endsection
