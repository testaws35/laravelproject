@extends('layouts.app1')
@section('content')

<!-- End Bradcaump area -->
<div class="page-blog-details section-padding--lg bg--white">
        <div class="container">
            <div class="row">
                 <div class="col-lg-9 col-12">
                    <div class="blog-details content">
                        <article class="blog-post-details">
                            <div class="post-thumbnail">
                            <h2 class="text-center" style="font-family: 'Sen', sans-serif;margin-top:-70px;"><b>{{ $templefunction->Title }}</b>
                               <a href="{{ route('templefunctions.index') }}" class="pull-left" title="Back to Temple Functions"><b style="font-size:10px;"><i class="fa fa-arrow-left fa-3x"></i></b></a> 
                            </h2>
                               <div class="blog-date-categori">
                               </div>
                                <div class="card-header card-header-image" style="margin-top:80px;">
                                      <a href="#">
                                      <img class="img-thumbnail" src="{{ $templefunction->Photo }}" style="max-height: 300px;width:90%">
                                      </a>
                                      <div class="colored-shadow" style="background-image: url('{{ $templefunction->Photo }}');opacity: 1;">
                                      </div>
                                </div>
                            </div>

                            <div class="post_wrapper">
                                <div class="post_header">
                                     <h2><!-- {{ $templefunction->Title }}   
                                             {{-- Edit button will be shown if User is Admin 
                                             or if the user is the author of the post and he can edit within 30 days --}}-->  
                                            <?php if( (Auth::user()->UserroleID == 2) ||  ($templefunction->Createdby == Auth::user()->id)) 
                                                  {  ?>
                                                <a href="{{ route('templefunctions.edit',$templefunction->TempleFunctionID) }}" class="pull-right"><b style="font-size:10px;"><i class="fa fa-edit fa-3x" title="Edit Temple Function"></i> </b></a> 
                                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                            <?php }?>
                                       <div class="blog-date-categori">
                                        <ul>
                                          
                                            <li class="text-uppercase"><strong>Function Date: {{ date('d-M-Y', strtotime($templefunction->FunctionDate )) }} </strong>
                                            </li>
                                        </ul>
                                        <ul>
                                            <li>Posted By : {{ $templefunction->name }}
                                            </li>
                                        </ul>

                                    </div>
                                </div>
                                <hr/>
                                <div class="post_content">
                                    <p><b class="text-uppercase"><strong>Description: </strong> </b> <br/>{{ $templefunction->Function_Content }}</p>
                               </div>
                               <hr/>
                           </div>
                        </article>
                     </div>
                </div>

                <div class="col-lg-3 col-12 md-mt-40 sm-mt-40">
                        <div class="wn__sidebar">
                           <!-- Start Single Widget -->
                            <aside class="widget recent_widget">
                                <h3 class="widget-title">Recent Functions</h3>
                                <div class="recent-posts">
                                    <ul>
                                        <li>
                                        @if( isset($templefunctions) )
                                         @foreach ($templefunctions->take(5) as $tempfunction)
                                                <div class="thumb" style="max-width:900px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"> 
                                                    @if($tempfunction->Photo )
                                                    <a href="{{ route('templefunctions.show',$tempfunction->TempleFunctionID) }}" style="text-decoration:none;"><img src="{{ $tempfunction->Photo }}" alt="Temple Function" class="rounded-circle"  width="50" height="50">&nbsp;    {{ $tempfunction->Title }}   </a>
                                                        @else 
                                                    <img class="img-thumbnail" src="/images/frontend_images/avatar.png" alt="templefunctions" class="rounded-circle"  width="50" height="50">
                                                    @endif
                                                </div><hr>
                      
                                           @endforeach
                                        @endif
                                        </li>
                                   </ul>
                                </div>
                            </aside>
                            <!-- End Single Widget -->

      <!-- Start Single Widget -->
      <aside class="wedget__categories poroduct--cat">
            <h3 class="wedget__title"><b>Archives </b></h3>
            <ul>
                
                <li><a href="{{ url('/templefunctions/?mon=1') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 1 months')  ) ); ?></a></li>
                <li><a href="{{ url('/templefunctions/?mon=2') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 2 months')  ) ); ?></a></li>
                <li><a href="{{ url('/templefunctions/?mon=3') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 3 months')  ) ); ?></a></li>
                <li><a href="{{ url('/templefunctions/?mon=4') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 4 months')  ) ); ?></a></li>
                <li><a href="{{ url('/templefunctions/?mon=5') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 5 months')  ) ); ?></a></li>
                <li><a href="{{ url('/templefunctions/?mon=6') }}"><?php echo date('F Y', ( strtotime(date('Y').'-'.date('m').'-'.date('j').' - 6 months')  ) ); ?></a></li>
              
            </ul>
        </aside>
        <!-- End Single Widget -->

                        </div>
                 </div>
        </div><!-- END ROW-->
     </div>
</div>

@endsection
